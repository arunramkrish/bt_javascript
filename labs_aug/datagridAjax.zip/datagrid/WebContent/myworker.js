onmessage = function(e) {
  console.log('Message received from web page');
//  var workerResult = {id: e.data[0], name: 'Arun', address : 'Bangalore'};
//  console.log('Posting message back to main script');
//  postMessage(workerResult);
	var xhr = new XMLHttpRequest();
	xhr.onreadystatechange = function() {
		if (xhr.readyState === 4) {
			if (xhr.status === 200) {
				postMessage(JSON.parse(xhr.responseText));
			}
		} 
	}
	xhr.open("GET", "employees.json", false);
	xhr.send(null);
};