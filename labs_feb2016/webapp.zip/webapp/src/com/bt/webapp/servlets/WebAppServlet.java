package com.bt.webapp.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bt.webapp.entity.Customer;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class WebAppServlet
 */
@WebServlet("/customers")
public class WebAppServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public WebAppServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Customer> customers = getCustomers();
		
		ObjectMapper mapper = new ObjectMapper();
		
		response.setHeader("Content-Type", "application/json");
		response.getOutputStream().print(mapper.writeValueAsString(customers));
		
	}

	private List<Customer> getCustomers() {
		List<Customer> cusList = new ArrayList<>();
		
		Customer c = new Customer(1L, "Arun", "Bangalore", "9449804064");
		cusList.add(c);
		
		c = new Customer(2L, "Arun", "Bangalore", "9449804064");
		cusList.add(c);
		
		c = new Customer(3L, "Arun", "Bangalore", "9449804064");
		cusList.add(c);
		
		c = new Customer(4L, "Arun", "Bangalore", "9449804064");
		cusList.add(c);
		
		c = new Customer(5L, "Arun", "Bangalore", "9449804064");
		cusList.add(c);
		
		return cusList;
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
