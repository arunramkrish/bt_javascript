module.exports = {
    host:'localhost',
    user:'root',
    password:'root',
    database:'projects',
    sayHello: function() {
        return "Hello from db";
    }
}