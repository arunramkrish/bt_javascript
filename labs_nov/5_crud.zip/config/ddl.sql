create table projects (id integer not null auto_increment primary key, name varchar(50), site varchar(100), description varchar(255));

INSERT INTO projects (name, site, description) VALUES ('BT1','bt.com/nodeProject1','Node project 1');