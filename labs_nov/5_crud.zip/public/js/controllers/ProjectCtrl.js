// public/js/controllers/ProjectCtrl.js
angular.module('ProjectCtrl', []).controller('ProjectController', function($scope) {

    $scope.tagline = 'Nothing beats a pocket protector!';

});