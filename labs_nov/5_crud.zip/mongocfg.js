module.exports = {
	mongourl: "mongodb://localhost:27017/crud"
}